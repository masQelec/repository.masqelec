pvr.demo.extras
===============
Dummy data and files to be used with the PVR Demo Add-on. This is aimed at XBMC skin developers.

This package was originally put together by Jezz_X. I just updated paths to keep it working in XBMC 13 and added the following:

- dummy recordings
- replaced the first tv channel (stream not working anymore)
- added more of the available genre colors in the epg
- added genre colors doc file

### Usage
Extract the contents of this file and copy it over into the pvr demo addons install directory (PVRDemoAddonSettings.xml needs to be overwritten). After that go into settings/livetv/general and select "Reset the PVR database" to get the new info.
