DATA_URL = 'https://i.mjh.nz/SamsungTVPlus/app.json.gz'
EPG_URL = 'https://i.mjh.nz/SamsungTVPlus/all.xml.gz'
ALL = '_'
