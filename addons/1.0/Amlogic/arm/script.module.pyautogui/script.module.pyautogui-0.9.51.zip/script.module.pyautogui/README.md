# PyAutoGUI port for Kodi 18+
PyAutoGUI is a  cross-platform GUI automation Python module for human beings. Used to programmatically control the mouse & keyboard.<br/><br/>

Full documentation available at https://pyautogui.readthedocs.org

Simplified Chinese documentation available at https://muxuezi.github.io/posts/doc-pyautogui.html

Source code available at https://github.com/asweigart/pyautogui  
