# -*- coding: utf-8 -*-

"""

			𝐕𝐈𝐑𝐓𝐔𝐀𝐋 𝐆𝐘𝐍 
		𝐁𝐘 𝐍𝐄𝐓𝐀𝐈 𝐓𝐄𝐀𝐌 𝟐𝟎𝟐𝟎
		
"""

import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import resolveurl
import cookielib , base64
import requests
import plugintools
import codecs
import start
